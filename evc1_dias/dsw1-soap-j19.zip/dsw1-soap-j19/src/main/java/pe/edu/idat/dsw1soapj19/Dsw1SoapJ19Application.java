package pe.edu.idat.dsw1soapj19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dsw1SoapJ19Application {

	public static void main(String[] args) {
		SpringApplication.run(Dsw1SoapJ19Application.class, args);
	}

}
