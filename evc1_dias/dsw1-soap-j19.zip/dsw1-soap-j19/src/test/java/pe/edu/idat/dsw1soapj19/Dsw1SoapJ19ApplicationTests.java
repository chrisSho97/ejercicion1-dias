package pe.edu.idat.dsw1soapj19;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dsw1SoapJ19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
